import discord
from keep_alive import keep_alive
from discord.ext import commands
import random
import smtplib
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import time

keep_alive()

############################################################
#
#Token
#
############################################################

TOKEN = os.getenv("DISCORD_TOKEN")  # Token - dis bota
if not TOKEN:
    print("WARNING: Není discord token.")
    exit(1)

############################################################
#
#Email setting
#
############################################################

EMAIL_PROVIDER = os.getenv("EMAIL_PROVIDER", "gmail").lower()

#porty pro gmail
if EMAIL_PROVIDER == "gmail":
    SMTP_SERVER = "smtp.gmail.com"
    SMTP_PORT = 587
    print("Using Gmail as email provider")

#port pro office
else:
    SMTP_SERVER = "smtp.office365.com"
    SMTP_PORT = 587
    print("Using Office 365 as email provider")

EMAIL_SENDER = os.getenv("EMAIL_SENDER")
if not EMAIL_SENDER:
    print("WARNING: Email není .")
    EMAIL_SENDER = ""

EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD")
if EMAIL_PASSWORD:
    EMAIL_PASSWORD = EMAIL_PASSWORD.replace(
        " ", "")  # Remove spaces from App password
if not EMAIL_PASSWORD:
    print("WARNING: Email password not found in environment variables.")
    print(
        "Please set the EMAIL_PASSWORD environment variable in Replit Secrets")
    if EMAIL_PROVIDER == "gmail":
        print("For Gmail accounts, you need to use an App Password:")
        print("1. Enable 2FA on your Google account")
        print(
            "2. Create an App Password at: myaccount.google.com → Security → App passwords"
        )
    else:
        print(
            "For Office 365/Outlook accounts, you need to use an App Password:"
        )
        print("1. Enable 2FA on your Microsoft account")
        print(
            "2. Create an App Password at: account.microsoft.com → Security → Advanced security options"
        )
    print(
        "3. Add the App Password to your environment variables as 'EMAIL_PASSWORD'"
    )
    EMAIL_PASSWORD = ""

verification_codes = {}

intents = discord.Intents.default()
intents.message_content = True
intents.members = True  # Potřeba pro správu rolí a přejmenování uživatelů
bot = commands.Bot(command_prefix="!", intents=intents)


# Improved email sending function with better error handling
def send_email(recipient, subject, body):
    # Check if email credentials are set
    if not EMAIL_SENDER or not EMAIL_PASSWORD:
        error_msg = "Email credentials are not set. Please configure EMAIL_SENDER and EMAIL_PASSWORD in Replit Secrets."
        print(error_msg)
        return False, error_msg

    try:
        # Create a proper MIME message
        msg = MIMEMultipart()
        msg['From'] = EMAIL_SENDER
        msg['To'] = recipient
        msg['Subject'] = subject

        # Add body to email
        msg.attach(MIMEText(body, 'plain'))

        # Connect to server
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.ehlo()  # Identify to the SMTP server
            server.starttls()  # Secure the connection
            server.ehlo()  # Re-identify over TLS connection

            # Login with debug info
            print(f"Attempting to login with email: {EMAIL_SENDER}")
            server.login(EMAIL_SENDER, EMAIL_PASSWORD)

            ############################################################
            #
            #Poslaní emailu
            #
            ############################################################
            text = msg.as_string()
            server.sendmail(EMAIL_SENDER, recipient, text)
            return True, "Email sent successfully"
    except smtplib.SMTPAuthenticationError as e:
        error_msg = f"Authentication failed: {e}"
        print(f"Authentication error details: {e}")
        print(f"Neni dobré heslo, email nebo neexistuje")
        return False, error_msg
    except smtplib.SMTPException as e:
        error_msg = f"SMTP error: {e}"
        print(f"SMTP error details: {e}")
        return False, error_msg
    except Exception as e:
        error_msg = f"Unexpected error: {e}"
        print(f"Unexpected error details: {e}")
        return False, error_msg


############################################################
#
#verifikace
#
############################################################
@bot.command()
async def register(ctx, email):
    # Normalize email to lowercase for consistency
    email = email.lower()

    # Check for valid school domains
    valid_domains = ["@student.souepl.cz", "@souepl.cz"]
    is_valid = any(email.endswith(domain) for domain in valid_domains)

    if not is_valid:
        await ctx.send("❌ Tento e-mail je špatnej. Použij pouze školní email.")
        return

    code = str(random.randint(100000, 999999))  # 6-místný kód
    verification_codes[ctx.author.id] = {"code": code, "email": email}
    #toto posílám do emailu
    subject = "Discord Bot - Ověřovací kód"
    body = f"""Ahoj,

Použij příkaz `!verify {code}` na Discordu.

"""

    # Enhanced logging
    print(
        f"User {ctx.author.name} (ID: {ctx.author.id}) registering with email: {email}"
    )
    print(f"Generated verification code: {code}")
    print(f"Current verification codes: {verification_codes}")

    success, message = send_email(email, subject, body)

    if success:
        await ctx.send(
            f"✅ Ověřovací kód byl odeslán na tvůj e-mail.\n Zkontroluj složku SPAM."
        )
    else:
        await ctx.send(f"❌ Chyba při odesílání e-mailu: {message}")


@bot.command()
async def verify(ctx, code: str):
    if ctx.author.id not in verification_codes:
        await ctx.send("❌ Nejsi registrován, použij !register [email]")
        return

    user_data = verification_codes[ctx.author.id]

    # Print debug information
    print(f"User {ctx.author.name} is verifying with code: {code}")
    print(f"Stored code for user: {user_data['code']}")

    email = user_data["email"]
    del verification_codes[ctx.author.id]  # vymazání kodu

    #rozdělení rolí
    email_domain = email.split("@")[-1]
    role_name = "Žák" if "student" in email_domain else "Učitel"

    role = discord.utils.get(ctx.guild.roles, name=role_name)
    if role is None:
        await ctx.send(f"❌ Role {role_name} neexistuje.")
        return

    try:
        await ctx.author.add_roles(role)
        await ctx.send(f"✅ Úspěšně přiřazena role: {role_name}")

        # 🔥 Přejmenování uživatele podle e-mailu
        username = email.split("@")[0]  # Odstraníme část za @

        if role_name == "Žák":
            username = username.replace(".", " ")  # Filip Drnec

        elif role_name == "Ředitel":
            username = "Ředitel"  # Pevné jméno pro ředitele

        elif role_name == "Učitel":
            if "." in username:
                username = username.split(".")[0].capitalize()  # Novak
            else:
                username = username.capitalize()  # Leba

        await ctx.author.edit(nick=username)
        await ctx.send(f"✏️ Uživatel byl přejmenován na: {username}")

    except discord.Forbidden:
        await ctx.send(
            "❌ Bot nemá oprávnění přiřazovat role nebo přejmenovávat uživatele."
        )
    except Exception as e:
        await ctx.send(f"❌ Chyba při přiřazování role nebo změně jména: {e}")


@bot.command()
async def debug(ctx):
    """Admin command to check verification codes"""
    # Only allow a specific admin user to use this command
    if ctx.author.id == ctx.guild.owner_id:  # Only server owner can use this
        if ctx.author.id in verification_codes:
            code_data = verification_codes[ctx.author.id]
            await ctx.send(f"Your verification code: {code_data['code']}")
        else:
            all_codes = "\n".join([
                f"User ID: {user_id}, Code: {data['code']}"
                for user_id, data in verification_codes.items()
            ])
            if all_codes:
                await ctx.send(f"All verification codes:\n{all_codes}")
            else:
                await ctx.send("No verification codes stored.")
    else:
        # Silently ignore if not admin
        pass


############################################################
#
#mazání msg
#
############################################################


@bot.event
async def on_message(message):
    """Smaže zprávy, které nejsou povolené příkazy."""
    if message.author == bot.user:
        return

    if not message.content.startswith(
        ("!register ", "!verify ", "!help", "!debug")):
        try:
            await message.delete()
            await message.channel.send(
                f"❌ {message.author.mention}, Toto není povoleno.\n Můžeš použít jenom\n !register \n !verify  ",
                delete_after=5)
        except discord.Forbidden:
            print("Bot nemá oprávnění mazat zprávy.")

    await bot.process_commands(message)


#to while mělo udělat to že když se něco pokazí tak ho hned zapne
while True:
    try:
        bot.run(TOKEN)  # Spustí bota
    except Exception as e:
        print(f"Bot je retard a spadl: {e}")
        time.sleep(5)
