
from ds_bot import bot
from keep_alive import keep_alive

keep_alive()
bot.run(bot.TOKEN)
